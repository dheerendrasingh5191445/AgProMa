﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace MyNeo4j.Viewmodel
{
    public class AvailableMember
    {
        public int MemberId { get; set; }

        public string MemberName { get; set; }

    }
}
