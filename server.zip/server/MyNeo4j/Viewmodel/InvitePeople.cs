﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace MyNeo4j.Viewmodel
{
    public class InvitePeople
    {
        public string Email { get; set; }

        public string ProjectId { get; set; }
    }
}
