export class Login{
     public FirstName:string
      public LastName:string  
      public Organization:string  
      public Department:string 
      public Email:string   
      public Password:string  
      public Id ?: number;
      public projectId?:number;
}