export class Epic{
    constructor(
        
       
        
        public projectId:number,
        
      
        
      
        
   
        
        public description:string,
        

        
        


    ){}}

   // "storyId":8,"projectId":1,"projectMaster":null,"storyName":"AS a hr user","priority":1,"comments":" ","inSprintNo":1,"status":true