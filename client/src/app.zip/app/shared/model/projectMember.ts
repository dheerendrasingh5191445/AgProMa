export class ProjectMember{
   
    
            public  ProjectId:number;   
            public  MemberId:number; 
            public ActAs:number;
            public id ?:number; 
        }