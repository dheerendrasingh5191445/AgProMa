export class Checklist {
    
    
          
          public taskId:number;
          public checklistName:string;
          public status:boolean;
          public checklistId?:number;

    }
    