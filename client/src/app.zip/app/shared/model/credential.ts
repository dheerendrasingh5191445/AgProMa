export class Credential{
    constructor(private userId:number,private status:string,private userName?:string,private email?:string){}
}