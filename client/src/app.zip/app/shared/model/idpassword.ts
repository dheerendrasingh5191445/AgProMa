export class IdPassword{
    constructor(private email:string,private password:string){}
}