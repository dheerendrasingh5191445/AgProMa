export class authentication{
    constructor(public Name:string,public Email:string){}
}