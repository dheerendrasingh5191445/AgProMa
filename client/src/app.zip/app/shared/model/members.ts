export class Members{
    constructor(private TeamId:number,private MemberId:number,private MemberName?:string,private Id?:number){}
}