export class ProductBacklog{
    constructor(
        
       
        
        public projectId:number,
        
        //public projectMaster:object,
        
        public storyName: string ,
        
        //public priority:number ,
        
        public comments:string,
        
       // public inSprintNo:number, 
        
        public  status:boolean,
        public priority:number


    ){}}

   // "storyId":8,"projectId":1,"projectMaster":null,"storyName":"AS a hr user","priority":1,"comments":" ","inSprintNo":1,"status":true