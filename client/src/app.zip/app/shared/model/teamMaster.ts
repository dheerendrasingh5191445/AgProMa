export class TeamMaster{
   constructor(private projectId:number,private teamName:string,private teamId?:number){}
}

