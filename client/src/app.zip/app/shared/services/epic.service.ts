import { Injectable } from '@angular/core';

import {HttpModule,Http,Response,Headers} from '@angular/http';
import 'rxjs/add/operator/map'; 
import 'rxjs/add/operator/catch';
import 'rxjs/add/observable/throw';
import { Observable } from "rxjs/Observable";
import { Epic } from "../model/epic";

@Injectable()
export class EpicService {
  EpicUrl:string="http://localhost:52258/api/epic";
 
    constructor(private http:Http) { }
    private headers=new Headers({'Content-Type':'application/json'});
    
    get(id) //for getting all epic based on projectid
    {
          
      return this.http.get(this.EpicUrl+'/'+id).map((res:Response)=>res.json());
    }
  add(item)//for adding new epic 
  {
    console.log("epic from service",item)
      return this.http.post(this.EpicUrl,item,{headers:this.headers});
  
  }
  update(id:any,item:any)//for updating particular epic based on epic id
  {
      {
          return this.http.put(this.EpicUrl+"/"+id,item ,{headers:this.headers}).catch((error:any)=>{
        
            return Observable.throw(error);
          })
        }
  
  }
  
  delete(id:any)//for deleting particular epic based on epic id.
  {
  
    return this.http.delete(this.EpicUrl+"/"+id);
  
          }
  
  }
  